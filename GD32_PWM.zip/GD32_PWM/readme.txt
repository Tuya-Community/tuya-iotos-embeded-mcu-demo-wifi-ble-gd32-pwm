GD32E230C通过按键和APP控制输出不同的PWM值，同时显示到APP上。
/*管脚： PB8--KEY   PA7 --PWM*/
