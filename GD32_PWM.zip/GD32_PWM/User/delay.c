#include "delay.h"
////////////////////////////////////////////////////////////////////////////////// 	 

void Delay_us(uint32_t time)  //us���ӳ�
{
	uint32_t i=0;  
	while(time--)
  {
		i=557;  
		while(i--) ;    
  }
}
void Delay_ms(uint32_t time)  //ms���ӳ�
{    
	uint32_t i=0;  
  while(time--)
  {
    i=5517;  
    while(i--) ;    
  }
}






































