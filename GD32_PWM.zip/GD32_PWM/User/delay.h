#ifndef __DELAY_H
#define __DELAY_H 	

#include "gd32e23x.h"	 
 
void Delay_us(uint32_t time);
void Delay_ms(uint32_t time);


#endif





























